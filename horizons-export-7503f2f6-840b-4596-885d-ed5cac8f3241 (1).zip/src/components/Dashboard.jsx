
import React, { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import { DatePicker } from "@/components/ui/date-picker"
import { Select } from "@/components/ui/select"
import { formatIndianNumber, getDateRangeFilter } from "@/lib/utils"
import { 
  ArrowUp, 
  ArrowDown, 
  CreditCard, 
  Package2, 
  UserCircle, 
  FileText, 
  BadgeInfo, 
  BarChart3,
  Receipt,
  Truck,
  RefreshCcw
} from 'lucide-react'

export function Dashboard() {
  const [transactions, setTransactions] = useState([])
  const [dateFilter, setDateFilter] = useState("allTime")
  const [customDateRange, setCustomDateRange] = useState({
    start: null,
    end: null
  })

  useEffect(() => {
    const storedTransactions = JSON.parse(localStorage.getItem("transactions") || "[]")
    setTransactions(storedTransactions.sort((a, b) => new Date(b.date) - new Date(a.date)))
  }, [])

  const filterTransactions = (transactions) => {
    if (dateFilter === "allTime") return transactions
    
    if (dateFilter === "custom" && customDateRange.start && customDateRange.end) {
      return transactions.filter(t => {
        const date = new Date(t.date)
        return date >= customDateRange.start && date <= customDateRange.end
      })
    }

    const dateRange = getDateRangeFilter(dateFilter)
    if (!dateRange) return transactions

    return transactions.filter(t => {
      const date = new Date(t.date)
      return date >= dateRange.start && date <= dateRange.end
    })
  }

  const filteredTransactions = filterTransactions(transactions)

  const totalSales = filteredTransactions
    .filter(t => t.type === "Sale")
    .reduce((sum, t) => sum + (parseFloat(t.totalAmount) || 0), 0)

  const totalPayments = filteredTransactions
    .filter(t => t.type === "Payment")
    .reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0)

  const totalOutstanding = totalSales - totalPayments

  const totalUnitsSold = filteredTransactions
    .filter(t => t.type === "Sale")
    .reduce((sum, t) => sum + (parseInt(t.quantity) || 0), 0)

  const totalReturns = filteredTransactions
    .filter(t => t.type === "Return")
    .reduce((sum, t) => sum + (parseFloat(t.totalAmount) || 0), 0)

  const totalReturnUnits = filteredTransactions
    .filter(t => t.type === "Return")
    .reduce((sum, t) => sum + (parseInt(t.quantity) || 0), 0)

  const paymentPercentage = totalSales > 0 ? ((totalPayments / totalSales) * 100).toFixed(1) : 0
  const outstandingPercentage = totalSales > 0 ? ((totalOutstanding / totalSales) * 100).toFixed(1) : 0

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: '2-digit',
      year: '2-digit',
      timeZone: 'Asia/Karachi'
    })
  }

  const getTransactionDescription = (transaction) => {
    switch (transaction.type) {
      case "Sale":
        return `${transaction.product} (${transaction.quantity}x${formatIndianNumber(transaction.rate)})`
      case "Payment":
        return `${transaction.bankAccount} - #${transaction.bankSlipNumber || "N/A"}`
      case "Return":
        return `${transaction.product} (${transaction.quantity}x${formatIndianNumber(transaction.rate)})`
      case "Cartage":
        return `${transaction.description || ""} - Paid By: ${transaction.paidBy === "Dealer" ? transaction.paidByDealer : "Company"}`
      default:
        return transaction.description || "-"
    }
  }

  const quickActions = [
    { 
      title: "Record Transaction", 
      icon: <FileText className="h-5 w-5 text-green-500" />, 
      link: "/forms?tab=transaction",
      bgColor: "bg-green-50"
    },
    { 
      title: "Add Product", 
      icon: <Package2 className="h-5 w-5 text-purple-500" />, 
      link: "/forms?tab=product",
      bgColor: "bg-purple-50" 
    },
    { 
      title: "Add Dealer", 
      icon: <UserCircle className="h-5 w-5 text-blue-500" />, 
      link: "/forms?tab=dealer",
      bgColor: "bg-blue-50"
    },
    { 
      title: "Add Bank Account", 
      icon: <BadgeInfo className="h-5 w-5 text-orange-500" />, 
      link: "/forms?tab=bank",
      bgColor: "bg-orange-50"
    }
  ]

  const accounts = [
    { 
      title: "All Transactions", 
      icon: <BarChart3 className="h-5 w-5 text-cyan-500" />, 
      link: "/transactions",
      bgColor: "bg-cyan-50"
    },
    { 
      title: "Dealer Ledgers", 
      icon: <FileText className="h-5 w-5 text-indigo-500" />, 
      link: "/dealers",
      bgColor: "bg-indigo-50"
    },
    { 
      title: "View Products", 
      icon: <Package2 className="h-5 w-5 text-yellow-500" />, 
      link: "/products",
      bgColor: "bg-yellow-50"
    },
    { 
      title: "View Bank Accounts", 
      icon: <BadgeInfo className="h-5 w-5 text-pink-500" />, 
      link: "/bank-accounts",
      bgColor: "bg-pink-50"
    },
    { 
      title: "View Slips", 
      icon: <Receipt className="h-5 w-5 text-emerald-500" />, 
      link: "/bank-slips",
      bgColor: "bg-emerald-50"
    },
    { 
      title: "View Bilties", 
      icon: <Truck className="h-5 w-5 text-rose-500" />, 
      link: "/bilties",
      bgColor: "bg-rose-50"
    }
  ]

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-gray-500">
            {new Date().toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric',
              timeZone: 'Asia/Karachi'
            })}
          </p>
        </div>
        <Select
          value={dateFilter}
          onChange={(e) => setDateFilter(e.target.value)}
          className="w-40"
        >
          <option value="allTime">All Time</option>
          <option value="today">Today</option>
          <option value="yesterday">Yesterday</option>
          <option value="thisMonth">This Month</option>
          <option value="thisYear">This Year</option>
          <option value="custom">Custom Range</option>
        </Select>
      </div>

      {dateFilter === "custom" && (
        <div className="grid grid-cols-2 gap-4">
          <DatePicker
            selected={customDateRange.start}
            onSelect={(date) => setCustomDateRange(prev => ({ ...prev, start: date }))}
          />
          <DatePicker
            selected={customDateRange.end}
            onSelect={(date) => setCustomDateRange(prev => ({ ...prev, end: date }))}
          />
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl p-6 shadow">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-500">Total Sales</p>
              <h2 className="text-3xl font-bold mt-2">{formatIndianNumber(totalSales)}</h2>
              <p className="text-sm text-gray-500 mt-1">{totalUnitsSold} Units Sold</p>
            </div>
            <div className="bg-green-100 p-2 rounded-full">
              <ArrowUp className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-500">Total Payments</p>
              <h2 className="text-3xl font-bold mt-2">{formatIndianNumber(totalPayments)}</h2>
              <p className="text-sm text-gray-500 mt-1">{paymentPercentage}% Payment Received</p>
            </div>
            <div className="bg-blue-100 p-2 rounded-full">
              <ArrowDown className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-500">Outstanding</p>
              <h2 className={`text-3xl font-bold mt-2 ${totalOutstanding > 0 ? 'text-red-600' : 'text-green-600'}`}>
                {formatIndianNumber(totalOutstanding)}
              </h2>
              <p className="text-sm text-gray-500 mt-1">{outstandingPercentage}% Outstanding</p>
            </div>
            <div className="bg-red-100 p-2 rounded-full">
              <CreditCard className="h-6 w-6 text-red-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl p-6 shadow">
          <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {quickActions.map((action, index) => (
              <Link
                key={index}
                to={action.link}
                className={`flex items-center p-4 rounded-lg border hover:bg-gray-50 transition-all duration-200 ${action.bgColor}`}
              >
                <div className="mr-3">{action.icon}</div>
                <span className="font-medium">{action.title}</span>
              </Link>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow">
          <h2 className="text-xl font-semibold mb-4">Accounts</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {accounts.map((account, index) => (
              <Link
                key={index}
                to={account.link}
                className={`flex items-center p-4 rounded-lg border hover:bg-gray-50 transition-all duration-200 ${account.bgColor}`}
              >
                <div className="mr-3">{account.icon}</div>
                <span className="font-medium">{account.title}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl p-6 shadow">
        <h2 className="text-xl font-semibold mb-4">Recent Transactions</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4">Date</th>
                <th className="text-left py-3 px-4">Type</th>
                <th className="text-left py-3 px-4">Dealer Name</th>
                <th className="text-left py-3 px-4">Description</th>
                <th className="text-right py-3 px-4">Quantity</th>
                <th className="text-right py-3 px-4">Rate</th>
                <th className="text-right py-3 px-4">Total Amount</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.slice(0, 5).map((transaction, index) => (
                <tr key={index} className="border-b">
                  <td className="py-3 px-4">{formatDate(transaction.date)}</td>
                  <td className="py-3 px-4">{transaction.type}</td>
                  <td className="py-3 px-4">{transaction.dealer}</td>
                  <td className="py-3 px-4">{getTransactionDescription(transaction)}</td>
                  <td className="py-3 px-4 text-right">{transaction.quantity || "-"}</td>
                  <td className="py-3 px-4 text-right">
                    {transaction.rate ? formatIndianNumber(transaction.rate) : "-"}
                  </td>
                  <td className="py-3 px-4 text-right">
                    {formatIndianNumber(
                      transaction.type === "Payment" || transaction.type === "Cartage"
                        ? transaction.amount
                        : transaction.totalAmount || 0
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
