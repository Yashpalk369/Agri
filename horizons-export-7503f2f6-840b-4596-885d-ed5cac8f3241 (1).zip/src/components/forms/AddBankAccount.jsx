
import React, { useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"

export function AddBankAccount() {
  const { toast } = useToast()
  const [formData, setFormData] = useState({
    accountTitle: "",
    accountNumber: "",
    totalReceived: "0"
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!formData.accountTitle || !formData.accountNumber) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please fill in all required fields"
      })
      return
    }

    // Save to localStorage for now
    const accounts = JSON.parse(localStorage.getItem("bankAccounts") || "[]")
    accounts.push(formData)
    localStorage.setItem("bankAccounts", JSON.stringify(accounts))

    toast({
      title: "Success",
      description: "Bank account added successfully"
    })

    setFormData({
      accountTitle: "",
      accountNumber: "",
      totalReceived: "0"
    })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="accountTitle">Account Title *</Label>
        <Input
          id="accountTitle"
          value={formData.accountTitle}
          onChange={(e) => setFormData({ ...formData, accountTitle: e.target.value })}
          placeholder="Enter account title"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="accountNumber">Account Number *</Label>
        <Input
          id="accountNumber"
          value={formData.accountNumber}
          onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
          placeholder="Enter account number"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="totalReceived">Total Received</Label>
        <Input
          id="totalReceived"
          type="number"
          value={formData.totalReceived}
          readOnly
        />
      </div>

      <Button type="submit" className="w-full">Add Bank Account</Button>
    </form>
  )
}
