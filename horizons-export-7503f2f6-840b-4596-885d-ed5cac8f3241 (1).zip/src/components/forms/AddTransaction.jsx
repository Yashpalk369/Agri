
import React, { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { useNavigate } from "react-router-dom"

export function AddTransaction() {
  const { toast } = useToast()
  const navigate = useNavigate()
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    type: "Sale",
    dealer: "",
    product: "",
    quantity: "",
    rate: "",
    totalAmount: "",
    bankAccount: "",
    bankSlipNumber: "",
    description: "",
    destinationDealer: "",
    paidBy: "",
    paidByDealer: ""
  })
  const [dealers, setDealers] = useState([])
  const [products, setProducts] = useState([])
  const [bankAccounts, setBankAccounts] = useState([])
  const [dealerProducts, setDealerProducts] = useState({})

  useEffect(() => {
    const storedDealers = JSON.parse(localStorage.getItem("dealers") || "[]")
    const storedProducts = JSON.parse(localStorage.getItem("products") || "[]")
    const storedBankAccounts = JSON.parse(localStorage.getItem("bankAccounts") || "[]")
    const storedTransactions = JSON.parse(localStorage.getItem("transactions") || "[]")
    
    // Calculate total units sold per dealer and product
    const dealerProductUnits = {}
    storedTransactions.forEach(t => {
      if (t.type === "Sale") {
        if (!dealerProductUnits[t.dealer]) {
          dealerProductUnits[t.dealer] = {}
        }
        if (!dealerProductUnits[t.dealer][t.product]) {
          dealerProductUnits[t.dealer][t.product] = 0
        }
        dealerProductUnits[t.dealer][t.product] += parseInt(t.quantity) || 0
      }
      if (t.type === "Return") {
        if (!dealerProductUnits[t.dealer]) {
          dealerProductUnits[t.dealer] = {}
        }
        if (!dealerProductUnits[t.dealer][t.product]) {
          dealerProductUnits[t.dealer][t.product] = 0
        }
        dealerProductUnits[t.dealer][t.product] -= parseInt(t.quantity) || 0
      }
    })
    
    setDealerProducts(dealerProductUnits)
    setDealers(storedDealers)
    setProducts(storedProducts)
    setBankAccounts(storedBankAccounts)
  }, [])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => {
      const newData = { ...prev, [name]: value }
      
      if (name === "quantity" || name === "rate") {
        const quantity = name === "quantity" ? value : prev.quantity
        const rate = name === "rate" ? value : prev.rate
        if (quantity && rate) {
          newData.totalAmount = (parseFloat(quantity) * parseFloat(rate)).toString()
        }
      }
      
      if (name === "product" && prev.type === "Return") {
        const availableUnits = dealerProducts[prev.dealer]?.[value] || 0
        if (parseInt(prev.quantity) > availableUnits) {
          toast({
            title: "Warning",
            description: `Only ${availableUnits} units available for return`,
            variant: "destructive"
          })
          newData.quantity = availableUnits.toString()
        }
      }
      
      if (name === "quantity" && prev.type === "Return") {
        const availableUnits = dealerProducts[prev.dealer]?.[prev.product] || 0
        if (parseInt(value) > availableUnits) {
          toast({
            title: "Warning",
            description: `Only ${availableUnits} units available for return`,
            variant: "destructive"
          })
          newData.quantity = availableUnits.toString()
        }
      }
      
      return newData
    })
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    
    try {
      const transactions = JSON.parse(localStorage.getItem("transactions") || "[]")
      transactions.push(formData)
      localStorage.setItem("transactions", JSON.stringify(transactions))
      
      setFormData({
        date: new Date().toISOString().split('T')[0],
        type: "Sale",
        dealer: "",
        product: "",
        quantity: "",
        rate: "",
        totalAmount: "",
        bankAccount: "",
        bankSlipNumber: "",
        description: "",
        destinationDealer: "",
        paidBy: "",
        paidByDealer: ""
      })
      
      toast({
        title: "Success",
        description: "Transaction added successfully",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add transaction",
        variant: "destructive",
      })
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex justify-end mb-6">
        <Button
          type="button"
          variant="outline"
          onClick={() => navigate("/transactions")}
        >
          View Transactions
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="date">Date</Label>
          <Input
            type="date"
            id="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            required
          />
        </div>
        
        <div>
          <Label htmlFor="type">Transaction Type</Label>
          <Select
            id="type"
            name="type"
            value={formData.type}
            onChange={handleChange}
            required
          >
            <option value="Sale">Sale</option>
            <option value="Payment">Payment</option>
            <option value="Return">Return</option>
            <option value="Cartage">Cartage</option>
          </Select>
        </div>

        <div>
          <Label htmlFor="dealer">Select Dealer</Label>
          <Select
            id="dealer"
            name="dealer"
            value={formData.dealer}
            onChange={handleChange}
            required
          >
            <option value="">Select Dealer</option>
            {dealers.map((dealer, index) => (
              <option key={index} value={dealer.name}>{dealer.name}</option>
            ))}
          </Select>
        </div>

        {formData.type === "Payment" && (
          <>
            <div>
              <Label htmlFor="bankAccount">Select Bank Account</Label>
              <Select
                id="bankAccount"
                name="bankAccount"
                value={formData.bankAccount}
                onChange={handleChange}
                required
              >
                <option value="">Select Bank Account</option>
                {bankAccounts.map((account, index) => (
                  <option key={index} value={account.accountTitle}>{account.accountTitle}</option>
                ))}
              </Select>
            </div>

            <div>
              <Label htmlFor="bankSlipNumber">Bank Slip Number</Label>
              <Input
                type="text"
                id="bankSlipNumber"
                name="bankSlipNumber"
                value={formData.bankSlipNumber}
                onChange={handleChange}
                required
              />
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Input
                type="text"
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                placeholder="Enter Description"
              />
            </div>

            <div>
              <Label htmlFor="amount">Amount</Label>
              <Input
                type="number"
                id="amount"
                name="amount"
                value={formData.amount}
                onChange={handleChange}
                required
              />
            </div>
          </>
        )}

        {formData.type === "Sale" && (
          <>
            <div>
              <Label htmlFor="product">Select Product</Label>
              <Select
                id="product"
                name="product"
                value={formData.product}
                onChange={handleChange}
                required
              >
                <option value="">Select Product</option>
                {products.map((product, index) => (
                  <option key={index} value={product.name}>{product.name}</option>
                ))}
              </Select>
            </div>

            <div>
              <Label htmlFor="quantity">Quantity</Label>
              <Input
                type="number"
                id="quantity"
                name="quantity"
                value={formData.quantity}
                onChange={handleChange}
                required
              />
            </div>

            <div>
              <Label htmlFor="rate">Rate</Label>
              <Input
                type="number"
                id="rate"
                name="rate"
                value={formData.rate}
                onChange={handleChange}
                required
              />
            </div>

            <div>
              <Label htmlFor="totalAmount">Total Amount</Label>
              <Input
                type="number"
                id="totalAmount"
                name="totalAmount"
                value={formData.totalAmount}
                onChange={handleChange}
                required
              />
            </div>

            <div>
              <Label htmlFor="biltyNumber">Bilty Number</Label>
              <Input
                type="text"
                id="biltyNumber"
                name="biltyNumber"
                value={formData.biltyNumber}
                onChange={handleChange}
                placeholder="Enter Bilty Number"
              />
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Input
                type="text"
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                placeholder="Enter Description"
              />
            </div>
          </>
        )}

        {formData.type === "Return" && (
          <>
            <div>
              <Label htmlFor="product">Select Product</Label>
              <Select
                id="product"
                name="product"
                value={formData.product}
                onChange={handleChange}
                required
              >
                <option value="">Select Product</option>
                {products.map((product, index) => (
                  <option key={index} value={product.name}>
                    {product.name} 
                    {formData.dealer && ` (Available: ${dealerProducts[formData.dealer]?.[product.name] || 0} units)`}
                  </option>
                ))}
              </Select>
            </div>

            <div>
              <Label htmlFor="quantity">Quantity</Label>
              <Input
                type="number"
                id="quantity"
                name="quantity"
                value={formData.quantity}
                onChange={handleChange}
                required
              />
            </div>

            <div>
              <Label htmlFor="rate">Rate</Label>
              <Input
                type="number"
                id="rate"
                name="rate"
                value={formData.rate}
                onChange={handleChange}
                required
              />
            </div>

            <div>
              <Label htmlFor="destinationDealer">Select Destination</Label>
              <Select
                id="destinationDealer"
                name="destinationDealer"
                value={formData.destinationDealer}
                onChange={handleChange}
                required
              >
                <option value="">Select Destination</option>
                <option value="Company">Company</option>
                {dealers.map((dealer, index) => (
                  <option key={index} value={dealer.name}>{dealer.name}</option>
                ))}
              </Select>
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Input
                type="text"
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                placeholder="Enter Description"
                required
              />
            </div>

            <div>
              <Label htmlFor="totalAmount">Total Amount</Label>
              <Input
                type="number"
                id="totalAmount"
                name="totalAmount"
                value={formData.totalAmount}
                onChange={handleChange}
                required
              />
            </div>
          </>
        )}

        {formData.type === "Cartage" && (
          <>
            <div>
              <Label htmlFor="paidBy">Paid By</Label>
              <Select
                id="paidBy"
                name="paidBy"
                value={formData.paidBy}
                onChange={handleChange}
                required
              >
                <option value="">Select Paid By</option>
                <option value="Company">Company</option>
                <option value="Dealer">Dealer</option>
              </Select>
            </div>

            {formData.paidBy === "Dealer" && (
              <div>
                <Label htmlFor="paidByDealer">Select Dealer</Label>
                <Select
                  id="paidByDealer"
                  name="paidByDealer"
                  value={formData.paidByDealer}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select Dealer</option>
                  {dealers.map((dealer, index) => (
                    <option key={index} value={dealer.name}>{dealer.name}</option>
                  ))}
                </Select>
              </div>
            )}

            <div>
              <Label htmlFor="description">Description</Label>
              <Input
                type="text"
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                placeholder="Enter Description"
                required
              />
            </div>

            <div>
              <Label htmlFor="amount">Amount</Label>
              <Input
                type="number"
                id="amount"
                name="amount"
                value={formData.amount}
                onChange={handleChange}
                required
              />
            </div>
          </>
        )}
      </div>

      <Button type="submit" className="w-full">
        Add Transaction
      </Button>
    </form>
  )
}
