
import React, { useState, useEffect } from "react"
import { formatIndianNumber } from "@/lib/utils"

export function ViewBankAccounts() {
  const [accounts, setAccounts] = useState([])
  const [transactions, setTransactions] = useState([])

  useEffect(() => {
    const storedAccounts = JSON.parse(localStorage.getItem("bankAccounts") || "[]")
    const storedTransactions = JSON.parse(localStorage.getItem("transactions") || "[]")
    setAccounts(storedAccounts)
    setTransactions(storedTransactions)
  }, [])

  const calculateTotalReceived = (accountNumber) => {
    return transactions
      .filter(t => t.type === "Payment" && t.bankAccount === accountNumber)
      .reduce((sum, t) => sum + parseFloat(t.amount || 0), 0)
  }

  return (
    <div className="mt-8">
      <h3 className="text-lg font-semibold mb-4">Bank Accounts</h3>
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="text-left p-4">Account Title</th>
                <th className="text-left p-4">Account Number</th>
                <th className="text-right p-4">Total Received</th>
              </tr>
            </thead>
            <tbody>
              {accounts.map((account, index) => (
                <tr key={index} className="border-t">
                  <td className="p-4">{account.accountTitle}</td>
                  <td className="p-4">{account.accountNumber}</td>
                  <td className="p-4 text-right">
                    {formatIndianNumber(calculateTotalReceived(account.accountNumber))}
                  </td>
                </tr>
              ))}
              {accounts.length === 0 && (
                <tr>
                  <td colSpan="3" className="p-4 text-center text-gray-500">
                    No bank accounts found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
