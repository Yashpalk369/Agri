
import React, { useState, useEffect } from "react"
import { formatIndianNumber } from "@/lib/utils"

export function ViewProducts() {
  const [products, setProducts] = useState([])

  useEffect(() => {
    const storedProducts = JSON.parse(localStorage.getItem("products") || "[]")
    setProducts(storedProducts)
  }, [])

  return (
    <div className="mt-8">
      <h3 className="text-lg font-semibold mb-4">Product List</h3>
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="text-left p-4">Product Name</th>
                <th className="text-right p-4">Size</th>
                <th className="text-left p-4">Unit</th>
                <th className="text-right p-4">Purchase Price</th>
                <th className="text-right p-4">Sale Price</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product, index) => (
                <tr key={index} className="border-t">
                  <td className="p-4">{product.name}</td>
                  <td className="p-4 text-right">{product.size}</td>
                  <td className="p-4">{product.unit}</td>
                  <td className="p-4 text-right">
                    {product.purchasePrice ? formatIndianNumber(product.purchasePrice) : "-"}
                  </td>
                  <td className="p-4 text-right">{formatIndianNumber(product.salePrice)}</td>
                </tr>
              ))}
              {products.length === 0 && (
                <tr>
                  <td colSpan="5" className="p-4 text-center text-gray-500">
                    No products found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
