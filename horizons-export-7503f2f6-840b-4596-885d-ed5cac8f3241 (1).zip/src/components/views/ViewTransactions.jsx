
import React, { useState, useEffect } from "react"
import { Select } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { DatePicker } from "@/components/ui/date-picker"
import { MoreVertical, ArrowUp, ArrowDown, CreditCard, Package2, RefreshCcw } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { 
  formatIndianNumber, 
  isToday, 
  isYesterday, 
  isThisWeek, 
  isThisMonth, 
  isThisYear, 
  isWithinRange 
} from "@/lib/utils"

export function ViewTransactions() {
  const [transactions, setTransactions] = useState([])
  const [dealers, setDealers] = useState([])
  const [products, setProducts] = useState([])
  const [bankAccounts, setBankAccounts] = useState([])
  const [filters, setFilters] = useState({
    date: "allTime",
    dealer: "all",
    product: "all",
    bankAccount: "all",
    type: "all"
  })
  const [customDateRange, setCustomDateRange] = useState({
    start: null,
    end: null
  })
  const [deleteConfirm, setDeleteConfirm] = useState(null)
  const [editTransaction, setEditTransaction] = useState(null)

  useEffect(() => {
    const storedTransactions = JSON.parse(localStorage.getItem("transactions") || "[]")
    const storedDealers = JSON.parse(localStorage.getItem("dealers") || "[]")
    const storedProducts = JSON.parse(localStorage.getItem("products") || "[]")
    const storedBankAccounts = JSON.parse(localStorage.getItem("bankAccounts") || "[]")
    
    setTransactions(storedTransactions.sort((a, b) => new Date(b.date) - new Date(a.date)))
    setDealers(storedDealers)
    setProducts(storedProducts)
    setBankAccounts(storedBankAccounts)
  }, [])

  const filterTransactions = (transactions) => {
    return transactions.filter(t => {
      const matchesDate = filters.date === "allTime" ? true : 
        filters.date === "today" ? isToday(new Date(t.date)) :
        filters.date === "yesterday" ? isYesterday(new Date(t.date)) :
        filters.date === "thisWeek" ? isThisWeek(new Date(t.date)) :
        filters.date === "thisMonth" ? isThisMonth(new Date(t.date)) :
        filters.date === "thisYear" ? isThisYear(new Date(t.date)) :
        filters.date === "custom" && customDateRange.start && customDateRange.end ? 
          isWithinRange(new Date(t.date), customDateRange.start, customDateRange.end) : true

      const matchesDealer = filters.dealer === "all" ? true : t.dealer === filters.dealer
      const matchesProduct = filters.product === "all" ? true : t.product === filters.product
      const matchesBankAccount = filters.bankAccount === "all" ? true : t.bankAccount === filters.bankAccount
      const matchesType = filters.type === "all" ? true : t.type === filters.type

      return matchesDate && matchesDealer && matchesProduct && matchesBankAccount && matchesType
    })
  }

  const filteredTransactions = filterTransactions(transactions)

  const totalSales = filteredTransactions
    .filter(t => t.type === "Sale")
    .reduce((sum, t) => sum + (parseFloat(t.totalAmount) || 0), 0)

  const totalPayments = filteredTransactions
    .filter(t => t.type === "Payment")
    .reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0)

  const totalOutstanding = totalSales - totalPayments

  const paymentPercentage = totalSales > 0 ? ((totalPayments / totalSales) * 100).toFixed(1) : 0
  const outstandingPercentage = totalSales > 0 ? ((totalOutstanding / totalSales) * 100).toFixed(1) : 0

  const totalUnitsSold = filteredTransactions
    .filter(t => t.type === "Sale")
    .reduce((sum, t) => sum + (parseInt(t.quantity) || 0), 0)

  const totalReturns = filteredTransactions
    .filter(t => t.type === "Return")
    .reduce((sum, t) => sum + (parseFloat(t.totalAmount) || 0), 0)

  const totalReturnUnits = filteredTransactions
    .filter(t => t.type === "Return")
    .reduce((sum, t) => sum + (parseInt(t.quantity) || 0), 0)

  const handleDelete = (index) => {
    const updatedTransactions = transactions.filter((_, i) => i !== index)
    localStorage.setItem("transactions", JSON.stringify(updatedTransactions))
    setTransactions(updatedTransactions)
    setDeleteConfirm(null)
  }

  const handleEdit = (transaction) => {
    const index = transactions.findIndex(t => 
      t.date === transaction.date && 
      t.type === transaction.type && 
      t.dealer === transaction.dealer
    )
    
    if (index !== -1) {
      const updatedTransactions = [...transactions]
      updatedTransactions[index] = transaction
      localStorage.setItem("transactions", JSON.stringify(updatedTransactions))
      setTransactions(updatedTransactions)
      setEditTransaction(null)
    }
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: '2-digit',
      year: '2-digit',
      timeZone: 'Asia/Karachi'
    })
  }

  const getTransactionDescription = (transaction) => {
    switch (transaction.type) {
      case "Sale":
        return `${transaction.product} (${transaction.quantity}x${formatIndianNumber(transaction.rate)})`
      case "Payment":
        return `Bank Payment - #${transaction.bankSlipNumber || "N/A"}`
      case "Return":
        return `${transaction.product} - To: ${transaction.stockDestination === "Dealer" ? transaction.destinationDealer : "Company"}`
      case "Cartage":
        return `${transaction.description || ""} - Paid By: ${transaction.paidBy === "Dealer" ? transaction.paidByDealer : "Company"}`
      default:
        return transaction.description || "-"
    }
  }

  return (
    <div className="p-6 space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl p-6 shadow">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-500">Total Sales</p>
              <h2 className="text-3xl font-bold mt-2">{formatIndianNumber(totalSales)}</h2>
              <p className="text-sm text-gray-500 mt-1">{totalUnitsSold} Units Sold</p>
            </div>
            <div className="bg-green-100 p-2 rounded-full">
              <ArrowUp className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-500">Total Payments</p>
              <h2 className="text-3xl font-bold mt-2">{formatIndianNumber(totalPayments)}</h2>
              <p className="text-sm text-gray-500 mt-1">{paymentPercentage}% Payment Received</p>
            </div>
            <div className="bg-blue-100 p-2 rounded-full">
              <ArrowDown className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-500">Outstanding</p>
              <h2 className={`text-3xl font-bold mt-2 ${totalOutstanding > 0 ? 'text-red-600' : 'text-green-600'}`}>
                {formatIndianNumber(totalOutstanding)}
              </h2>
              <p className="text-sm text-gray-500 mt-1">{outstandingPercentage}% Outstanding</p>
            </div>
            <div className="bg-red-100 p-2 rounded-full">
              <CreditCard className="h-6 w-6 text-red-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-500">Returns</p>
              <h2 className="text-3xl font-bold mt-2">{formatIndianNumber(totalReturns)}</h2>
              <p className="text-sm text-gray-500 mt-1">{totalReturnUnits} Units Returned</p>
            </div>
            <div className="bg-yellow-100 p-2 rounded-full">
              <RefreshCcw className="h-6 w-6 text-yellow-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl p-6 shadow">
        <div className="flex flex-wrap gap-4 mb-6">
          <Select
            value={filters.date}
            onChange={(e) => setFilters(prev => ({ ...prev, date: e.target.value }))}
            className="w-40"
          >
            <option value="allTime">All Time</option>
            <option value="today">Today</option>
            <option value="yesterday">Yesterday</option>
            <option value="thisWeek">This Week</option>
            <option value="thisMonth">This Month</option>
            <option value="thisYear">This Year</option>
            <option value="custom">Custom Range</option>
          </Select>

          {filters.date === "custom" && (
            <div className="flex gap-4">
              <DatePicker
                selected={customDateRange.start}
                onSelect={(date) => setCustomDateRange(prev => ({ ...prev, start: date }))}
                placeholder="Start Date"
              />
              <DatePicker
                selected={customDateRange.end}
                onSelect={(date) => setCustomDateRange(prev => ({ ...prev, end: date }))}
                placeholder="End Date"
              />
            </div>
          )}

          <Select
            value={filters.dealer}
            onChange={(e) => setFilters(prev => ({ ...prev, dealer: e.target.value }))}
            className="w-40"
          >
            <option value="all">All Dealers</option>
            {dealers.map((dealer, index) => (
              <option key={index} value={dealer.name}>{dealer.name}</option>
            ))}
          </Select>

          <Select
            value={filters.product}
            onChange={(e) => setFilters(prev => ({ ...prev, product: e.target.value }))}
            className="w-40"
          >
            <option value="all">All Products</option>
            {products.map((product, index) => (
              <option key={index} value={product.name}>{product.name}</option>
            ))}
          </Select>

          <Select
            value={filters.bankAccount}
            onChange={(e) => setFilters(prev => ({ ...prev, bankAccount: e.target.value }))}
            className="w-40"
          >
            <option value="all">All Bank Accounts</option>
            {bankAccounts.map((account, index) => (
              <option key={index} value={account.title}>{account.title}</option>
            ))}
          </Select>

          <Select
            value={filters.type}
            onChange={(e) => setFilters(prev => ({ ...prev, type: e.target.value }))}
            className="w-40"
          >
            <option value="all">All Types</option>
            <option value="Sale">Sales</option>
            <option value="Payment">Payments</option>
            <option value="Return">Returns</option>
            <option value="Cartage">Cartage</option>
          </Select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="text-left p-4">SN</th>
                <th className="text-left p-4">Date</th>
                <th className="text-left p-4">Type</th>
                <th className="text-left p-4">Dealer Name</th>
                <th className="text-left p-4">Description</th>
                <th className="text-right p-4">Quantity</th>
                <th className="text-right p-4">Rate</th>
                <th className="text-right p-4">Total Amount</th>
                <th className="text-center p-4">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.map((transaction, index) => (
                <tr key={index} className="border-t">
                  <td className="p-4">{index + 1}</td>
                  <td className="p-4">{formatDate(transaction.date)}</td>
                  <td className="p-4">{transaction.type}</td>
                  <td className="p-4">{transaction.dealer}</td>
                  <td className="p-4">{getTransactionDescription(transaction)}</td>
                  <td className="p-4 text-right">{transaction.quantity || "-"}</td>
                  <td className="p-4 text-right">
                    {transaction.rate ? formatIndianNumber(transaction.rate) : "-"}
                  </td>
                  <td className="p-4 text-right">
                    {formatIndianNumber(
                      transaction.type === "Payment" || transaction.type === "Cartage"
                        ? transaction.amount
                        : transaction.totalAmount || 0
                    )}
                  </td>
                  <td className="p-4 text-center">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem
                          onClick={() => handleEdit(transaction)}
                        >
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => setDeleteConfirm(index)}
                          className="text-red-600"
                        >
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              ))}
              {filteredTransactions.length === 0 && (
                <tr>
                  <td colSpan="9" className="p-4 text-center text-gray-500">
                    No transactions found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <AlertDialog open={deleteConfirm !== null} onOpenChange={() => setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the transaction.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => handleDelete(deleteConfirm)}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
