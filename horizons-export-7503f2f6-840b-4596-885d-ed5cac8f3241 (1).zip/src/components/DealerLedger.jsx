
import React, { useState, useEffect } from "react"
import { useParams } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from "@/components/ui/dropdown-menu"
import { formatIndianNumber } from "@/lib/utils"
import { FileDown } from "lucide-react"
import jsPDF from 'jspdf'
import * as XLSX from 'xlsx'

export function DealerLedger() {
  const { id } = useParams()
  const [transactions, setTransactions] = useState([])
  const [dealer, setDealer] = useState(null)

  useEffect(() => {
    const storedTransactions = JSON.parse(localStorage.getItem("transactions") || "[]")
    const dealerTransactions = storedTransactions.filter(t => t.dealer === id)
    setTransactions(dealerTransactions)

    const storedDealers = JSON.parse(localStorage.getItem("dealers") || "[]")
    const dealerData = storedDealers.find(d => d.name === id)
    setDealer(dealerData)
  }, [id])

  const totalSales = transactions
    .filter(t => t.type === "Sale")
    .reduce((sum, t) => sum + parseFloat(t.totalAmount || 0), 0)

  const totalPayments = transactions
    .filter(t => t.type === "Payment")
    .reduce((sum, t) => sum + parseFloat(t.amount || 0), 0)

  const outstanding = totalSales - totalPayments

  const paymentPercentage = totalSales > 0 ? ((totalPayments / totalSales) * 100).toFixed(1) : 0
  const outstandingPercentage = totalSales > 0 ? ((outstanding / totalSales) * 100).toFixed(1) : 0

  const downloadLedger = (format) => {
    const ledgerData = ledgerEntries.map((entry, index) => ({
      SN: index + 1,
      Date: new Date(entry.date).toLocaleDateString('en-GB', {
        day: '2-digit',
        month: '2-digit',
        year: '2-digit'
      }),
      Type: entry.type,
      Description: entry.type === "Sale"
        ? `${entry.product} (${entry.quantity}x${entry.rate})`
        : `Bank Payment - #${entry.bankSlipNumber || "N/A"}`,
      Debit: entry.type === "Payment" ? entry.amount : "",
      Credit: entry.type === "Sale" ? entry.totalAmount : "",
      Balance: entry.balance
    }))

    if (format === 'pdf') {
      const doc = new jsPDF()
      
      // Add header
      doc.setFontSize(20)
      doc.text(`Dealer Ledger - ${dealer?.name}`, 20, 20)
      
      // Add summary
      doc.setFontSize(12)
      doc.text(`Total Sales: ${formatIndianNumber(totalSales)}`, 20, 35)
      doc.text(`Total Payments: ${formatIndianNumber(totalPayments)}`, 20, 45)
      doc.text(`Outstanding: ${formatIndianNumber(outstanding)}`, 20, 55)
      
      // Add table
      const headers = ['SN', 'Date', 'Type', 'Description', 'Debit', 'Credit', 'Balance']
      const data = ledgerData.map(entry => Object.values(entry))
      
      doc.autoTable({
        head: [headers],
        body: data,
        startY: 70,
        styles: { fontSize: 8 },
        columnStyles: {
          0: { cellWidth: 15 },
          1: { cellWidth: 25 },
          2: { cellWidth: 25 },
          3: { cellWidth: 40 },
          4: { cellWidth: 25, halign: 'right' },
          5: { cellWidth: 25, halign: 'right' },
          6: { cellWidth: 25, halign: 'right' }
        }
      })
      
      doc.save(`${dealer?.name}_ledger.pdf`)
    } else if (format === 'excel') {
      const wb = XLSX.utils.book_new()
      const ws = XLSX.utils.json_to_sheet(ledgerData)
      XLSX.utils.book_append_sheet(wb, ws, "Ledger")
      XLSX.writeFile(wb, `${dealer?.name}_ledger.xlsx`)
    }
  }

  let balance = 0
  const ledgerEntries = transactions
    .sort((a, b) => new Date(a.date) - new Date(b.date))
    .map(t => {
      if (t.type === "Sale") {
        balance += parseFloat(t.totalAmount || 0)
      } else if (t.type === "Payment") {
        balance -= parseFloat(t.amount || 0)
      }
      return { ...t, balance }
    })

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Dealer Ledger - {dealer?.name}</h2>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm">
              <FileDown className="h-4 w-4 mr-2" />
              Download Ledger
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => downloadLedger('pdf')}>
              Download PDF
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => downloadLedger('excel')}>
              Download Excel
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-xl shadow">
          <h3 className="text-xl font-bold">{dealer?.name}</h3>
          <div className="space-y-2 text-gray-600 mt-2">
            <p>Phone: {dealer?.phone || "N/A"}</p>
            <p>Location: {dealer?.location || "N/A"}</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow">
          <h3 className="text-gray-500">Total Sales</h3>
          <p className="text-3xl font-bold mt-2">{formatIndianNumber(totalSales)}</p>
          <p className="text-sm text-gray-500 mt-1">100% Total</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow">
          <h3 className="text-gray-500">Total Payments</h3>
          <p className="text-3xl font-bold mt-2">{formatIndianNumber(totalPayments)}</p>
          <p className="text-sm text-gray-500 mt-1">{paymentPercentage}% Payment Received</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow">
          <h3 className="text-gray-500">Outstanding</h3>
          <p className={`text-3xl font-bold mt-2 ${outstanding > 0 ? "text-red-600" : "text-green-600"}`}>
            {formatIndianNumber(outstanding)}
          </p>
          <p className="text-sm text-gray-500 mt-1">{outstandingPercentage}% Outstanding</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 border-b">
                <th className="text-left p-4 font-medium">SN</th>
                <th className="text-left p-4 font-medium">Date</th>
                <th className="text-left p-4 font-medium">Type</th>
                <th className="text-left p-4 font-medium">Description</th>
                <th className="text-right p-4 font-medium">Debit</th>
                <th className="text-right p-4 font-medium">Credit</th>
                <th className="text-right p-4 font-medium">Balance</th>
              </tr>
            </thead>
            <tbody>
              {ledgerEntries.map((entry, index) => (
                <tr key={index} className="border-b">
                  <td className="p-4">{index + 1}</td>
                  <td className="p-4">{new Date(entry.date).toLocaleDateString('en-GB', {
                    day: '2-digit',
                    month: '2-digit',
                    year: '2-digit'
                  })}</td>
                  <td className="p-4">{entry.type}</td>
                  <td className="p-4">
                    {entry.type === "Sale"
                      ? `${entry.product} (${entry.quantity}x${formatIndianNumber(entry.rate)})`
                      : entry.type === "Payment"
                      ? `Bank Payment - #${entry.bankSlipNumber || "N/A"}`
                      : "-"}
                  </td>
                  <td className="p-4 text-right">
                    {entry.type === "Payment"
                      ? formatIndianNumber(entry.amount)
                      : ""}
                  </td>
                  <td className="p-4 text-right">
                    {entry.type === "Sale"
                      ? formatIndianNumber(entry.totalAmount)
                      : ""}
                  </td>
                  <td className={`p-4 text-right ${
                    entry.balance > 0 ? "text-red-600" : "text-green-600"
                  }`}>
                    {formatIndianNumber(entry.balance)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
