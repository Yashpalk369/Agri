
import React, { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import { Input } from "@/components/ui/input"
import { Select } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from "@/components/ui/dropdown-menu"
import { formatIndianNumber } from "@/lib/utils"
import { Search as SearchIcon, MoreVertical, FileDown } from "lucide-react"
import jsPDF from 'jspdf'
import * as XLSX from 'xlsx'

export function DealersList() {
  const [dealers, setDealers] = useState([])
  const [transactions, setTransactions] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState("name")
  const [sortOrder, setSortOrder] = useState("asc")
  const [balanceFilter, setBalanceFilter] = useState("all")

  useEffect(() => {
    const storedDealers = JSON.parse(localStorage.getItem("dealers") || "[]")
    const storedTransactions = JSON.parse(localStorage.getItem("transactions") || "[]")
    setDealers(storedDealers)
    setTransactions(storedTransactions)
  }, [])

  const getDealerTransactions = (dealerName) => {
    return transactions.filter(t => t.dealer === dealerName)
  }

  const calculateDealerTotals = (dealerName) => {
    const dealerTransactions = getDealerTransactions(dealerName)
    const sales = dealerTransactions
      .filter(t => t.type === "Sale")
      .reduce((sum, t) => sum + parseFloat(t.totalAmount || 0), 0)
    const payments = dealerTransactions
      .filter(t => t.type === "Payment")
      .reduce((sum, t) => sum + parseFloat(t.amount || 0), 0)
    const outstanding = sales - payments
    return { sales, payments, outstanding }
  }

  const totalSales = dealers.reduce((sum, dealer) => {
    const { sales } = calculateDealerTotals(dealer.name)
    return sum + sales
  }, 0)

  const totalPayments = dealers.reduce((sum, dealer) => {
    const { payments } = calculateDealerTotals(dealer.name)
    return sum + payments
  }, 0)

  const totalOutstanding = totalSales - totalPayments

  const downloadLedger = (dealer, format) => {
    const dealerTransactions = getDealerTransactions(dealer.name)
    
    if (format === 'pdf') {
      const doc = new jsPDF()
      doc.text(`Ledger for ${dealer.name}`, 20, 10)
      // Add more PDF formatting here
      doc.save(`${dealer.name}_ledger.pdf`)
    } else if (format === 'excel') {
      const wb = XLSX.utils.book_new()
      const ws = XLSX.utils.json_to_sheet(dealerTransactions)
      XLSX.utils.book_append_sheet(wb, ws, "Ledger")
      XLSX.writeFile(wb, `${dealer.name}_ledger.xlsx`)
    }
  }

  const filteredDealers = dealers
    .filter(dealer => {
      const matchesSearch = dealer.name.toLowerCase().includes(searchTerm.toLowerCase())
      const { outstanding } = calculateDealerTotals(dealer.name)
      const matchesBalance = balanceFilter === "all" ||
        (balanceFilter === "positive" && outstanding > 0) ||
        (balanceFilter === "negative" && outstanding < 0) ||
        (balanceFilter === "zero" && outstanding === 0)
      return matchesSearch && matchesBalance
    })
    .sort((a, b) => {
      let comparison = 0
      if (sortBy === "name") {
        comparison = a.name.localeCompare(b.name)
      } else if (sortBy === "outstanding") {
        const { outstanding: aOutstanding } = calculateDealerTotals(a.name)
        const { outstanding: bOutstanding } = calculateDealerTotals(b.name)
        comparison = aOutstanding - bOutstanding
      }
      return sortOrder === "asc" ? comparison : -comparison
    })

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Dealer Ledgers</h1>
          <p className="text-gray-500">View and manage all dealer accounts</p>
        </div>
        <Link to="/dashboard" className="text-blue-600 hover:text-blue-800">
          Back to Dashboard
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold mb-2">Total Sales</h3>
          <p className="text-2xl font-bold">{formatIndianNumber(totalSales)}</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold mb-2">Total Payments</h3>
          <p className="text-2xl font-bold">{formatIndianNumber(totalPayments)}</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold mb-2">Total Outstanding</h3>
          <p className={`text-2xl font-bold ${totalOutstanding > 0 ? "text-red-600" : "text-green-600"}`}>
            {formatIndianNumber(totalOutstanding)}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="relative">
          <SearchIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search dealers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>

        <Select
          value={balanceFilter}
          onChange={(e) => setBalanceFilter(e.target.value)}
          className="w-full"
        >
          <option value="all">All Balances</option>
          <option value="positive">Positive Balance</option>
          <option value="negative">Negative Balance</option>
          <option value="zero">Zero Balance</option>
        </Select>

        <Select
          value={`${sortBy}-${sortOrder}`}
          onChange={(e) => {
            const [newSortBy, newSortOrder] = e.target.value.split("-")
            setSortBy(newSortBy)
            setSortOrder(newSortOrder)
          }}
          className="w-full"
        >
          <option value="name-asc">Name (A-Z)</option>
          <option value="name-desc">Name (Z-A)</option>
          <option value="outstanding-asc">Outstanding (Low to High)</option>
          <option value="outstanding-desc">Outstanding (High to Low)</option>
        </Select>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 border-b">
                <th className="text-left p-4 font-medium">SN</th>
                <th className="text-left p-4 font-medium">Dealer Name</th>
                <th className="text-right p-4 font-medium">Sales</th>
                <th className="text-right p-4 font-medium">Payments</th>
                <th className="text-right p-4 font-medium">Outstanding</th>
                <th className="text-center p-4 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredDealers.map((dealer, index) => {
                const { sales, payments, outstanding } = calculateDealerTotals(dealer.name)
                return (
                  <tr key={index} className="border-b">
                    <td className="p-4">{index + 1}</td>
                    <td className="p-4">
                      <Link 
                        to={`/dealer/${dealer.name}`}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        {dealer.name}
                      </Link>
                    </td>
                    <td className="p-4 text-right">{formatIndianNumber(sales)}</td>
                    <td className="p-4 text-right">{formatIndianNumber(payments)}</td>
                    <td className={`p-4 text-right ${
                      outstanding > 0 ? "text-red-600" : "text-green-600"
                    }`}>
                      {formatIndianNumber(outstanding)}
                    </td>
                    <td className="p-4 text-center">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => downloadLedger(dealer, 'pdf')}>
                            <FileDown className="mr-2 h-4 w-4" />
                            Download PDF
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => downloadLedger(dealer, 'excel')}>
                            <FileDown className="mr-2 h-4 w-4" />
                            Download Excel
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
