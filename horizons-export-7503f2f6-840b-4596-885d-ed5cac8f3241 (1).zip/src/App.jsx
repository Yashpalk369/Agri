
import React from "react"
import { BrowserRouter as Router, Routes, Route, Navigate, useSearchParams } from "react-router-dom"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AddProduct } from "@/components/forms/AddProduct"
import { AddDealer } from "@/components/forms/AddDealer"
import { AddTransaction } from "@/components/forms/AddTransaction"
import { AddBankAccount } from "@/components/forms/AddBankAccount"
import { ViewProducts } from "@/components/views/ViewProducts"
import { ViewDealers } from "@/components/views/ViewDealers"
import { ViewTransactions } from "@/components/views/ViewTransactions"
import { ViewBankAccounts } from "@/components/views/ViewBankAccounts"
import { ViewBankSlips } from "@/components/views/ViewBankSlips"
import { ViewBilty } from "@/components/views/ViewBilty"
import { Dashboard } from "@/components/Dashboard"
import { DealerLedger } from "@/components/DealerLedger"
import { DealersList } from "@/components/DealersList"
import { Toaster } from "@/components/ui/toaster"

function Forms() {
  const [searchParams] = useSearchParams()
  const defaultTab = searchParams.get("tab") || "transaction"

  return (
    <div className="p-4 md:p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Agri Accounting System</h1>
        <p className="mt-2 text-gray-600">Manage your agricultural business finances efficiently</p>
      </header>

      <Tabs defaultValue={defaultTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4 gap-4 p-1 bg-white rounded-lg shadow">
          <TabsTrigger value="transaction" className="data-[state=active]:bg-primary data-[state=active]:text-white transition-all duration-200">Add Transaction</TabsTrigger>
          <TabsTrigger value="product" className="data-[state=active]:bg-primary data-[state=active]:text-white transition-all duration-200">Add Product</TabsTrigger>
          <TabsTrigger value="dealer" className="data-[state=active]:bg-primary data-[state=active]:text-white transition-all duration-200">Add Dealer</TabsTrigger>
          <TabsTrigger value="bank" className="data-[state=active]:bg-primary data-[state=active]:text-white transition-all duration-200">Add Bank Account</TabsTrigger>
        </TabsList>
        
        <div className="bg-white rounded-lg shadow-lg p-6">
          <TabsContent value="transaction" className="mt-0 transition-all duration-200">
            <AddTransaction />
            <ViewTransactions />
          </TabsContent>
          <TabsContent value="product" className="mt-0 transition-all duration-200">
            <AddProduct />
            <ViewProducts />
          </TabsContent>
          <TabsContent value="dealer" className="mt-0 transition-all duration-200">
            <AddDealer />
            <ViewDealers />
          </TabsContent>
          <TabsContent value="bank" className="mt-0 transition-all duration-200">
            <AddBankAccount />
            <ViewBankAccounts />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
              <ViewBankSlips />
              <ViewBilty />
            </div>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
        <div className="mx-auto max-w-7xl">
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/dealers" element={<DealersList />} />
            <Route path="/dealer/:id" element={<DealerLedger />} />
            <Route path="/forms" element={<Forms />} />
            <Route path="/transactions" element={<ViewTransactions />} />
            <Route path="/products" element={<ViewProducts />} />
            <Route path="/bank-accounts" element={<ViewBankAccounts />} />
            <Route path="/bank-slips" element={<ViewBankSlips />} />
            <Route path="/bilties" element={<ViewBilty />} />
          </Routes>
        </div>
        <Toaster />
      </div>
    </Router>
  )
}
